# Dev Loop Installation

> Quick setup guide for Agentic Development (Level 2)

---

## Installation (3 Steps)

### Step 1: Copy to Your Project

```bash
# Copy the dev folder
cp -r .claude/dev/ /path/to/your-project/.claude/dev/

# Copy the agents
cp -r .claude/agents/dev/ /path/to/your-project/.claude/agents/dev/

# Copy the command
cp -r .claude/commands/dev/ /path/to/your-project/.claude/commands/dev/
```

### Step 2: Verify Structure

Your project should now have:

```text
your-project/
└── .claude/
    ├── dev/                          # Dev Loop workspace
    │   ├── _index.md
    │   ├── readme.md
    │   ├── tasks/                    # Your PROMPT files go here
    │   │   └── .gitkeep
    │   ├── progress/                 # Auto-managed
    │   │   └── .gitkeep
    │   ├── logs/                     # Execution logs
    │   │   └── .gitkeep
    │   ├── templates/                # Copy and customize these
    │   │   ├── PROMPT_TEMPLATE.md
    │   │   ├── PROGRESS_TEMPLATE.md
    │   │   ├── PROMPT_EXAMPLE_FEATURE.md
    │   │   └── PROMPT_EXAMPLE_KB.md
    │   └── examples/                 # Real-world examples
    │
    ├── agents/
    │   └── dev/
    │       ├── prompt-crafter.md     # Question-first PROMPT builder
    │       └── dev-loop-executor.md  # Structured executor
    │
    └── commands/
        └── dev/
            └── dev.md                # /dev command definition
```

### Step 3: Start Using

```bash
# Let the crafter guide you (recommended)
/dev "I want to build a date parser"

# Or execute an existing PROMPT
/dev tasks/PROMPT_MY_TASK.md
```

---

## Quick Reference

| Command | Description |
|---------|-------------|
| `/dev "description"` | Start with prompt-crafter (question-first) |
| `/dev tasks/PROMPT_*.md` | Execute a PROMPT file |
| `/dev tasks/PROMPT_*.md --resume` | Resume interrupted session |
| `/dev tasks/PROMPT_*.md --dry-run` | Validate without executing |
| `/dev --list` | List available PROMPTs |

---

## Files Included

| Count | Type | Files |
|-------|------|-------|
| 2 | Agents | prompt-crafter.md, dev-loop-executor.md |
| 1 | Command | dev.md |
| 4 | Templates | PROMPT_TEMPLATE.md, PROGRESS_TEMPLATE.md, examples |
| 2 | Documentation | _index.md, readme.md |
| 4 | Examples | Real-world PROMPT, PROGRESS, LOG files |

**Total:** ~18 files, ~3,500 lines

---

## Customization

### Adapt Agent References

The templates reference generic agents. Update with your project's specialists:

```markdown
# In your PROMPT files, change:
- [ ] @python-developer: Write the parser

# To your specific agents:
- [ ] @my-custom-agent: Write the parser
```

### Modify Quality Tiers

Adjust `quality_tier` in PROMPT config based on your needs:

```yaml
quality_tier: prototype   # Fast iteration
quality_tier: production  # Full testing
quality_tier: library     # API stability
```

---

## Learn More

- **Full Documentation:** `.claude/dev/_index.md`
- **Feature Overview:** `.claude/dev/readme.md`
- **Real Examples:** `.claude/dev/examples/`

---

*Dev Loop v1.1 — Ask first, execute perfectly, recover gracefully*
