# AgentSpec 4.2 - Quick Install Guide

> AI-Native Specification Framework for Claude Code

---

## Installation

1. **Extract the zip** to your project root:

```bash
unzip sdd-agentic-spec-v4.2.zip -d your-project/
```

2. **Verify structure:**

```text
your-project/
└── .claude/
    ├── sdd/           # Spec-Driven Development artifacts
    ├── agents/        # Workflow agents (6 agents)
    └── commands/      # Slash commands (6 commands)
```

---

## Quick Start

### Option A: Start with Clear Requirements

```bash
/define "Build a REST API for user authentication"
/design .claude/sdd/features/DEFINE_USER_AUTH.md
/build .claude/sdd/features/DESIGN_USER_AUTH.md
/ship .claude/sdd/features/DEFINE_USER_AUTH.md
```

### Option B: Start with Exploration

```bash
/brainstorm "I want to add caching but not sure how"
/define .claude/sdd/features/BRAINSTORM_CACHING.md
# Continue with /design → /build → /ship
```

---

## The 5-Phase Pipeline

```text
/brainstorm → /define → /design → /build → /ship
   (Opus)      (Opus)    (Opus)   (Sonnet)  (Haiku)
```

| Phase | Command | Purpose |
| ----- | ------- | ------- |
| 0 | `/brainstorm` | Explore ideas (optional) |
| 1 | `/define` | Capture requirements |
| 2 | `/design` | Create architecture + Agent Matching |
| 3 | `/build` | Execute with Agent Delegation |
| 4 | `/ship` | Archive with lessons learned |

---

## Key Features (v4.2)

- **Agent Matching** - Design phase assigns specialists to tasks
- **Agent Delegation** - Build phase invokes specialists via Task tool
- **Technical Context** - Define phase captures Location, KB Domains, IaC Impact
- **Agent Attribution** - Build reports track which agent created each file

---

## Included Files

| Directory | Contents |
| --------- | -------- |
| `.claude/sdd/` | Templates, architecture, examples |
| `.claude/agents/workflow/` | 6 workflow agents |
| `.claude/commands/workflow/` | 6 slash commands |

---

## Documentation

- **Full Documentation:** `.claude/sdd/README.md`
- **Quick Reference:** `.claude/sdd/_index.md`
- **Examples:** `.claude/sdd/examples/`
- **Release Notes:** `.claude/sdd/GITHUB_RELEASE_CHECKLIST.md`

---

## Optional: Add Knowledge Base

For KB-grounded patterns, add your own `.claude/kb/` directory:

```text
.claude/kb/
├── _index.yaml       # KB registry
├── pydantic/         # Data validation patterns
├── your-domain/      # Your custom patterns
└── ...
```

---

## Support

- GitHub Issues: https://github.com/owshq-academy/agentspec/issues
- Documentation: `.claude/sdd/README.md`

---

*AgentSpec v4.2.0 - "Tell me WHAT to build, I'll figure out WHO should build it"*
